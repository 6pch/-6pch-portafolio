import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        bg: "#12141C",
        surface: "#1B1E2B",
        surface2: "#242838",
        ink: "#E8E6F0",
        muted: "#8B8FA3",
        accent: "#7C9EFF",
        amber: "#FFB86B",
        mint: "#6EE7B7",
        rose: "#FF7A93",
      },
      fontFamily: {
        display: ["Space Grotesk", "sans-serif"],
        body: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      borderRadius: {
        sig: "14px",
      },
    },
  },
  plugins: [],
};
export default config;
