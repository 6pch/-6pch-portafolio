"use client";
import { motion } from "framer-motion";
import Link from "next/link";
import { LikeButton } from "./LikeButton";

type Project = {
  id: string;
  title: string;
  description: string;
  repoUrl?: string | null;
  demoUrl?: string | null;
  tags: string;
  likeCount: number;
};

export function ProjectCard({ project, index }: { project: Project; index: number }) {
  const tags = project.tags.split(",").filter(Boolean);
  return (
    <motion.article
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="rounded-sig border border-white/8 bg-surface p-6 flex flex-col gap-3 hover:border-accent/40 transition-colors"
    >
      <h3 className="font-display text-lg font-semibold">{project.title}</h3>
      <p className="text-muted text-sm leading-relaxed">{project.description}</p>
      <div className="flex flex-wrap gap-2 font-mono text-xs">
        {tags.map((t) => (
          <span key={t} className="px-2 py-0.5 rounded-full bg-surface2 text-amber">#{t.trim()}</span>
        ))}
      </div>
      <div className="flex items-center justify-between mt-2 pt-3 border-t border-white/5">
        <div className="flex gap-3 font-mono text-xs">
          {project.repoUrl && (
            <a href={project.repoUrl} target="_blank" className="text-accent hover:underline">codigo →</a>
          )}
          {project.demoUrl && (
            <a href={project.demoUrl} target="_blank" className="text-accent hover:underline">demo →</a>
          )}
        </div>
        <LikeButton targetType="project" targetId={project.id} initialCount={project.likeCount} />
      </div>
    </motion.article>
  );
}
