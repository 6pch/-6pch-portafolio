"use client";
import { useState } from "react";
import { motion } from "framer-motion";

export function LikeButton({
  targetType,
  targetId,
  initialCount,
}: {
  targetType: "project" | "post";
  targetId: string;
  initialCount: number;
}) {
  const [count, setCount] = useState(initialCount);
  const [liked, setLiked] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleLike() {
    if (liked || loading) return;
    setLoading(true);
    try {
      const res = await fetch("/api/likes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetType, targetId }),
      });
      if (res.ok) {
        setCount((c) => c + 1);
        setLiked(true);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={handleLike}
      disabled={liked || loading}
      className={`flex items-center gap-1.5 font-mono text-xs px-2.5 py-1 rounded-full border transition-colors ${
        liked ? "border-mint/50 text-mint bg-mint/10" : "border-white/10 text-muted hover:border-mint/40 hover:text-mint"
      }`}
    >
      <span>{liked ? "★" : "☆"}</span>
      <span>{count}</span>
    </motion.button>
  );
}
