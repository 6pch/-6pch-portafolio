"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { MarkdownRenderer } from "./MarkdownRenderer";

type PostData = { id?: string; title: string; excerpt: string; content: string; published: boolean };

export function PostForm({ initial }: { initial?: PostData }) {
  const router = useRouter();
  const [form, setForm] = useState<PostData>(initial ?? { title: "", excerpt: "", content: "", published: false });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(false);

  function update<K extends keyof PostData>(key: K, value: PostData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const url = initial?.id ? `/api/posts/${initial.id}` : "/api/posts";
    const method = initial?.id ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setSaving(false);
    if (res.ok) {
      router.push("/admin/posts");
      router.refresh();
    } else {
      setError("No se pudo guardar el post.");
    }
  }

  async function handleDelete() {
    if (!initial?.id) return;
    if (!confirm("¿Borrar este post? No se puede deshacer.")) return;
    await fetch(`/api/posts/${initial.id}`, { method: "DELETE" });
    router.push("/admin/posts");
    router.refresh();
  }

  const inputClass = "bg-surface2 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-accent w-full";

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-3xl">
      <label className="flex flex-col gap-1 text-sm">
        Título
        <input required className={inputClass} value={form.title} onChange={(e) => update("title", e.target.value)} />
      </label>

      <label className="flex flex-col gap-1 text-sm">
        Resumen (aparece en el listado)
        <input className={inputClass} value={form.excerpt} onChange={(e) => update("excerpt", e.target.value)} />
      </label>

      <div className="flex items-center justify-between">
        <span className="text-sm">Contenido (Markdown)</span>
        <button type="button" onClick={() => setPreview((p) => !p)} className="font-mono text-xs text-accent">
          {preview ? "editar" : "vista previa"}
        </button>
      </div>

      {preview ? (
        <div className="border border-white/10 rounded-lg p-4 bg-surface2 min-h-[220px]">
          <MarkdownRenderer content={form.content} />
        </div>
      ) : (
        <textarea
          rows={14}
          className={inputClass + " font-mono"}
          value={form.content}
          onChange={(e) => update("content", e.target.value)}
        />
      )}

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={form.published} onChange={(e) => update("published", e.target.checked)} />
        Publicado (visible en el blog)
      </label>

      {error && <p className="text-rose text-sm font-mono">{error}</p>}

      <div className="flex gap-3 mt-2">
        <button type="submit" disabled={saving} className="bg-accent text-bg font-medium rounded-lg px-4 py-2 text-sm disabled:opacity-50">
          {saving ? "Guardando..." : "Guardar"}
        </button>
        {initial?.id && (
          <button type="button" onClick={handleDelete} className="text-rose font-mono text-sm px-4 py-2">
            Borrar post
          </button>
        )}
      </div>
    </form>
  );
}
