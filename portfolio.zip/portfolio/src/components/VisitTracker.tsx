"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";

// Contador de visitas propio: registra cada cambio de ruta.
// No usa cookies ni guarda datos personales, solo la ruta y la fecha.
export function VisitTracker() {
  const pathname = usePathname();
  useEffect(() => {
    fetch("/api/visits", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path: pathname }),
    }).catch(() => {});
  }, [pathname]);
  return null;
}
