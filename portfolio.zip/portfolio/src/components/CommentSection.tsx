"use client";
import { useState } from "react";
import { motion } from "framer-motion";

type Comment = { id: string; author: string; body: string; createdAt: string };

export function CommentSection({ postId, initialComments }: { postId: string; initialComments: Comment[] }) {
  const [comments, setComments] = useState(initialComments);
  const [author, setAuthor] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!author.trim() || !body.trim()) return;
    setSending(true);
    setError("");
    const res = await fetch("/api/comments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ postId, author, body }),
    });
    setSending(false);
    if (res.ok) {
      const newComment = await res.json();
      setComments((c) => [{ ...newComment, createdAt: newComment.createdAt }, ...c]);
      setBody("");
    } else {
      setError("No se pudo publicar el comentario.");
    }
  }

  return (
    <div className="mt-12">
      <h3 className="font-display text-lg font-semibold mb-4">
        Comentarios <span className="text-muted font-mono text-sm">({comments.length})</span>
      </h3>

      <form onSubmit={handleSubmit} className="flex flex-col gap-3 mb-8">
        <input
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
          placeholder="Tu nombre"
          maxLength={60}
          required
          className="bg-surface2 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-accent"
        />
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Escribe un comentario..."
          maxLength={1000}
          required
          rows={3}
          className="bg-surface2 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-accent resize-none"
        />
        {error && <p className="text-rose text-xs font-mono">{error}</p>}
        <button
          type="submit"
          disabled={sending}
          className="self-start bg-accent text-bg text-sm font-medium rounded-lg px-4 py-2 hover:opacity-90 disabled:opacity-50"
        >
          {sending ? "Enviando..." : "Publicar comentario"}
        </button>
      </form>

      <div className="flex flex-col gap-4">
        {comments.map((c) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="border-l-2 border-white/10 pl-4"
          >
            <p className="font-mono text-xs text-amber">{c.author}</p>
            <p className="text-sm text-ink mt-1">{c.body}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
