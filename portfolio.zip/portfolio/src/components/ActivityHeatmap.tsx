"use client";
import { motion } from "framer-motion";

// Elemento firma: un mapa de calor estilo "contribuciones de GitHub",
// pero alimentado con datos reales de visitas del propio sitio.
// weeks: array de 26 semanas x 7 dias con un nivel de actividad 0-4
export function ActivityHeatmap({ weeks }: { weeks: number[][] }) {
  const levelColor = ["#1B1E2B", "#2A3A5C", "#3F5FA8", "#5A80D8", "#7C9EFF"];

  return (
    <div className="flex gap-[3px] overflow-x-auto pb-2">
      {weeks.map((week, wi) => (
        <div key={wi} className="flex flex-col gap-[3px]">
          {week.map((level, di) => (
            <motion.div
              key={di}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: (wi * 7 + di) * 0.003, duration: 0.25 }}
              className="w-[10px] h-[10px] rounded-[2px]"
              style={{ backgroundColor: levelColor[level] }}
              title={`nivel de actividad: ${level}`}
            />
          ))}
        </div>
      ))}
    </div>
  );
}
