"use client";
import { useState } from "react";

export function PasswordChangeForm() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  const inputClass = "bg-surface2 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-accent w-full";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);

    if (newPassword !== confirm) {
      setMessage({ type: "error", text: "Las contraseñas nuevas no coinciden." });
      return;
    }

    setSaving(true);
    const res = await fetch("/api/admin/password", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
    setSaving(false);

    if (res.ok) {
      setMessage({ type: "ok", text: "Contraseña actualizada correctamente." });
      setCurrentPassword("");
      setNewPassword("");
      setConfirm("");
    } else {
      const data = await res.json().catch(() => ({}));
      setMessage({ type: "error", text: data.error ?? "No se pudo cambiar la contraseña." });
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-sm">
      <label className="flex flex-col gap-1 text-sm">
        Contraseña actual
        <input type="password" required className={inputClass} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        Contraseña nueva
        <input type="password" required minLength={8} className={inputClass} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
      </label>
      <label className="flex flex-col gap-1 text-sm">
        Repite la contraseña nueva
        <input type="password" required minLength={8} className={inputClass} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
      </label>

      {message && (
        <p className={`text-sm font-mono ${message.type === "ok" ? "text-mint" : "text-rose"}`}>{message.text}</p>
      )}

      <button type="submit" disabled={saving} className="self-start bg-accent text-bg font-medium rounded-lg px-4 py-2 text-sm disabled:opacity-50">
        {saving ? "Guardando..." : "Cambiar contraseña"}
      </button>
    </form>
  );
}
