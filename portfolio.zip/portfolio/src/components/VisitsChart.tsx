"use client";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function VisitsChart({ data }: { data: { date: string; visitas: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <LineChart data={data}>
        <CartesianGrid stroke="#242838" strokeDasharray="3 3" />
        <XAxis dataKey="date" stroke="#8B8FA3" fontSize={11} />
        <YAxis stroke="#8B8FA3" fontSize={11} allowDecimals={false} />
        <Tooltip contentStyle={{ background: "#1B1E2B", border: "1px solid #2A2E40", borderRadius: 8, fontSize: 12 }} />
        <Line type="monotone" dataKey="visitas" stroke="#7C9EFF" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
