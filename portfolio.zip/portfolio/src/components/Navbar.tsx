import Link from "next/link";
import { ThemeToggle } from "./ThemeToggle";

export function Navbar() {
  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-bg/70 border-b border-white/5">
      <nav className="max-w-5xl mx-auto flex items-center justify-between px-5 py-4">
        <Link href="/" className="font-display font-semibold tracking-tight text-lg">
          <span className="text-accent">~/</span>portfolio
        </Link>
        <div className="flex items-center gap-6 font-mono text-sm text-muted">
          <Link href="/#proyectos" className="hover:text-ink transition-colors">proyectos</Link>
          <Link href="/blog" className="hover:text-ink transition-colors">blog</Link>
          <ThemeToggle />
        </div>
      </nav>
    </header>
  );
}
