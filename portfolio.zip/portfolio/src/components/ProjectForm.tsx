"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type ProjectData = {
  id?: string;
  title: string;
  description: string;
  content: string;
  imageUrl: string;
  repoUrl: string;
  demoUrl: string;
  tags: string;
  featured: boolean;
};

export function ProjectForm({ initial }: { initial?: ProjectData }) {
  const router = useRouter();
  const [form, setForm] = useState<ProjectData>(
    initial ?? { title: "", description: "", content: "", imageUrl: "", repoUrl: "", demoUrl: "", tags: "", featured: false }
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function update<K extends keyof ProjectData>(key: K, value: ProjectData[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const url = initial?.id ? `/api/projects/${initial.id}` : "/api/projects";
    const method = initial?.id ? "PUT" : "POST";
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    if (res.ok) {
      router.push("/admin/projects");
      router.refresh();
    } else {
      setError("No se pudo guardar el proyecto.");
    }
  }

  async function handleDelete() {
    if (!initial?.id) return;
    if (!confirm("¿Borrar este proyecto? No se puede deshacer.")) return;
    await fetch(`/api/projects/${initial.id}`, { method: "DELETE" });
    router.push("/admin/projects");
    router.refresh();
  }

  const inputClass = "bg-surface2 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-accent w-full";

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4 max-w-xl">
      <label className="flex flex-col gap-1 text-sm">
        Título
        <input required className={inputClass} value={form.title} onChange={(e) => update("title", e.target.value)} />
      </label>

      <label className="flex flex-col gap-1 text-sm">
        Descripción corta (aparece en la tarjeta)
        <input required className={inputClass} value={form.description} onChange={(e) => update("description", e.target.value)} />
      </label>

      <label className="flex flex-col gap-1 text-sm">
        Contenido detallado (Markdown, opcional)
        <textarea rows={6} className={inputClass} value={form.content} onChange={(e) => update("content", e.target.value)} />
      </label>

      <label className="flex flex-col gap-1 text-sm">
        Etiquetas (separadas por coma)
        <input className={inputClass} placeholder="python, bot, discord" value={form.tags} onChange={(e) => update("tags", e.target.value)} />
      </label>

      <div className="grid sm:grid-cols-2 gap-4">
        <label className="flex flex-col gap-1 text-sm">
          URL del repositorio
          <input className={inputClass} value={form.repoUrl} onChange={(e) => update("repoUrl", e.target.value)} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          URL de la demo
          <input className={inputClass} value={form.demoUrl} onChange={(e) => update("demoUrl", e.target.value)} />
        </label>
      </div>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={form.featured} onChange={(e) => update("featured", e.target.checked)} />
        Destacar este proyecto
      </label>

      {error && <p className="text-rose text-sm font-mono">{error}</p>}

      <div className="flex gap-3 mt-2">
        <button type="submit" disabled={saving} className="bg-accent text-bg font-medium rounded-lg px-4 py-2 text-sm disabled:opacity-50">
          {saving ? "Guardando..." : "Guardar"}
        </button>
        {initial?.id && (
          <button type="button" onClick={handleDelete} className="text-rose font-mono text-sm px-4 py-2">
            Borrar proyecto
          </button>
        )}
      </div>
    </form>
  );
}
