import { createHash } from "crypto";

// Genera un identificador anonimo (no un dato personal identificable)
// a partir de IP + user-agent, para evitar likes/visitas duplicados
// sin guardar datos reales del visitante.
export function makeFingerprint(ip: string, userAgent: string) {
  return createHash("sha256").update(`${ip}::${userAgent}`).digest("hex").slice(0, 24);
}
