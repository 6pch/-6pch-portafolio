// Limitador de peticiones sencillo, en memoria, sin dependencias externas.
//
// Limitación conocida: en un entorno serverless (Vercel) cada instancia de
// función tiene su propia memoria, así que este límite es "por instancia",
// no global. Para un portfolio personal con tráfico bajo es suficiente y
// evita el 99% del spam automatizado. Si el sitio crece mucho, la mejora
// natural es mover esto a Upstash Redis (tiene plan gratis y una API muy
// simple), pero no hace falta para empezar.
type Entry = { count: number; resetAt: number };

const hits = new Map<string, Entry>();

// Limpieza periódica para no acumular memoria indefinidamente.
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of hits) {
    if (entry.resetAt < now) hits.delete(key);
  }
}, 5 * 60 * 1000);

/**
 * Devuelve true si la petición está permitida, false si se ha superado el límite.
 * @param key identificador único (normalmente `ruta:ip`)
 * @param max número máximo de peticiones permitidas en la ventana de tiempo
 * @param windowMs duración de la ventana en milisegundos
 */
export function checkRateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = hits.get(key);

  if (!entry || entry.resetAt < now) {
    hits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }

  if (entry.count >= max) return false;

  entry.count += 1;
  return true;
}

/** Extrae una IP "razonable" de la petición para usarla como clave del límite. */
export function getClientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  return forwarded?.split(",")[0]?.trim() ?? "unknown";
}
