import { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { checkRateLimit } from "./rateLimit";

export const authOptions: AuthOptions = {
  session: { strategy: "jwt", maxAge: 12 * 60 * 60 }, // 12h: sesiones cortas para un panel admin
  pages: { signIn: "/admin/login" },
  providers: [
    CredentialsProvider({
      name: "Admin",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) return null;

        // Frena ataques de fuerza bruta contra el login: 5 intentos cada 15 min por IP.
        const ip = req?.headers?.["x-forwarded-for"]?.toString() ?? "unknown";
        const allowed = checkRateLimit(`login:${ip}`, 5, 15 * 60 * 1000);
        if (!allowed) return null;

        const admin = await prisma.adminUser.findUnique({
          where: { email: credentials.email.toLowerCase().trim() },
        });
        // Comparamos siempre contra un hash (aunque no exista el usuario) para no
        // filtrar por tiempo de respuesta si un email existe o no.
        const hashToCompare = admin?.passwordHash ?? "$2a$12$invalidinvalidinvalidinvalidinvalidinva";
        const valid = await bcrypt.compare(credentials.password, hashToCompare);
        if (!admin || !valid) return null;

        return { id: admin.id, email: admin.email, name: "Admin" };
      },
    }),
  ],
};
