import { z } from "zod";

// Centralizar los esquemas aquí evita duplicar reglas de validación entre
// rutas y hace explícito qué datos aceptamos de fuentes no confiables (el navegador).

export const projectSchema = z.object({
  title: z.string().trim().min(1, "El título es obligatorio").max(120),
  description: z.string().trim().min(1, "La descripción es obligatoria").max(300),
  content: z.string().max(20000).optional().default(""),
  imageUrl: z.string().trim().url().max(500).optional().or(z.literal("")),
  repoUrl: z.string().trim().url().max(500).optional().or(z.literal("")),
  demoUrl: z.string().trim().url().max(500).optional().or(z.literal("")),
  tags: z.string().max(200).optional().default(""),
  featured: z.boolean().optional().default(false),
});

export const postSchema = z.object({
  title: z.string().trim().min(1, "El título es obligatorio").max(160),
  excerpt: z.string().trim().max(300).optional().default(""),
  content: z.string().min(1, "El contenido es obligatorio").max(50000),
  published: z.boolean().optional().default(false),
});

export const commentSchema = z.object({
  postId: z.string().min(1),
  author: z.string().trim().min(1, "Pon un nombre").max(60),
  body: z.string().trim().min(1, "El comentario está vacío").max(1000),
});

export const likeSchema = z.object({
  targetType: z.enum(["project", "post"]),
  targetId: z.string().min(1),
});

export const visitSchema = z.object({
  path: z.string().max(200).optional().default("/"),
});

export const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8, "La contraseña nueva debe tener al menos 8 caracteres").max(200),
});

/** Convierte los errores de zod en un mensaje corto y legible para el usuario. */
export function firstZodError(error: z.ZodError): string {
  return error.issues[0]?.message ?? "Datos inválidos";
}
