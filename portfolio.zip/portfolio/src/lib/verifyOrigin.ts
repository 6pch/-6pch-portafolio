// Defensa extra contra CSRF para las rutas que modifican datos del panel admin.
//
// NextAuth ya protege la sesión con una cookie httpOnly + SameSite=Lax, lo cual
// evita la mayoría de ataques CSRF por sí solo. Esta comprobación añade una
// segunda capa: verifica que la petición viene realmente del propio sitio,
// comparando la cabecera Origin con el host esperado.
export function isSameOriginRequest(req: Request): boolean {
  const origin = req.headers.get("origin");
  // Peticiones sin cabecera Origin (algunos clientes API, curl, etc.) no se
  // bloquean aquí porque ya requieren la cookie de sesión, que no pueden falsificar.
  if (!origin) return true;

  const host = req.headers.get("host");
  if (!host) return false;

  try {
    const originHost = new URL(origin).host;
    return originHost === host;
  } catch {
    return false;
  }
}
