import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { MarkdownRenderer } from "@/components/MarkdownRenderer";
import { LikeButton } from "@/components/LikeButton";
import { CommentSection } from "@/components/CommentSection";

export default async function PostPage({ params }: { params: { slug: string } }) {
  const post = await prisma.post.findUnique({
    where: { slug: params.slug },
    include: {
      comments: { orderBy: { createdAt: "desc" } },
      likes: true,
    },
  });

  if (!post || !post.published) notFound();

  return (
    <article className="max-w-2xl mx-auto px-5 py-14">
      <p className="font-mono text-xs text-muted mb-2">
        {post.createdAt.toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" })}
      </p>
      <h1 className="font-display text-3xl font-bold mb-4">{post.title}</h1>
      <div className="mb-8">
        <LikeButton targetType="post" targetId={post.id} initialCount={post.likes.length} />
      </div>

      <MarkdownRenderer content={post.content} />

      <CommentSection
        postId={post.id}
        initialComments={post.comments.map((c) => ({ ...c, createdAt: c.createdAt.toISOString() }))}
      />
    </article>
  );
}
