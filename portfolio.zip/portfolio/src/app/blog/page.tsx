import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function BlogList() {
  const posts = await prisma.post.findMany({
    where: { published: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="max-w-3xl mx-auto px-5 py-14">
      <h1 className="font-display text-3xl font-bold mb-8">Blog</h1>
      {posts.length === 0 && <p className="text-muted">Todavía no hay posts publicados.</p>}
      <div className="flex flex-col gap-6">
        {posts.map((post) => (
          <Link
            key={post.id}
            href={`/blog/${post.slug}`}
            className="block bg-surface border border-white/8 rounded-sig p-6 hover:border-accent/40 transition-colors"
          >
            <p className="font-mono text-xs text-muted mb-2">
              {post.createdAt.toLocaleDateString("es-ES", { day: "numeric", month: "long", year: "numeric" })}
            </p>
            <h2 className="font-display text-xl font-semibold mb-2">{post.title}</h2>
            <p className="text-muted text-sm">{post.excerpt}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
