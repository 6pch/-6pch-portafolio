import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { makeFingerprint } from "@/lib/fingerprint";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { likeSchema, firstZodError } from "@/lib/validation";

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  // Máximo 30 likes cada 10 minutos por IP: suficiente para un uso normal,
  // insuficiente para un script que intente inflar los contadores.
  if (!checkRateLimit(`like:${ip}`, 30, 10 * 60 * 1000)) {
    return NextResponse.json({ error: "Demasiadas peticiones, espera un poco." }, { status: 429 });
  }

  const parsed = likeSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: firstZodError(parsed.error) }, { status: 400 });
  }
  const { targetType, targetId } = parsed.data;

  const userAgent = req.headers.get("user-agent") ?? "unknown";
  const fingerprint = makeFingerprint(ip, userAgent);

  try {
    if (targetType === "project") {
      await prisma.like.create({ data: { projectId: targetId, fingerprint } });
    } else {
      await prisma.like.create({ data: { postId: targetId, fingerprint } });
    }
    return NextResponse.json({ ok: true });
  } catch {
    // La restricción única de la base de datos salta si ya había dado like antes.
    return NextResponse.json({ error: "Ya le diste like a esto." }, { status: 409 });
  }
}
