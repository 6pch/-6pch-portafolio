import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { commentSchema, firstZodError } from "@/lib/validation";

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  // Máximo 5 comentarios cada 5 minutos por IP: frena bots de spam
  // sin molestar a una persona real conversando en el blog.
  if (!checkRateLimit(`comment:${ip}`, 5, 5 * 60 * 1000)) {
    return NextResponse.json({ error: "Demasiados comentarios seguidos, espera un poco." }, { status: 429 });
  }

  const parsed = commentSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: firstZodError(parsed.error) }, { status: 400 });
  }
  const { postId, author, body } = parsed.data;

  const post = await prisma.post.findUnique({ where: { id: postId } });
  if (!post || !post.published) {
    return NextResponse.json({ error: "Post no encontrado." }, { status: 404 });
  }

  // React escapa el texto al renderizarlo (no interpreta HTML), así que
  // guardar el texto tal cual es seguro: no hace falta sanitizar HTML aquí.
  const comment = await prisma.comment.create({
    data: { postId, author, body },
  });
  return NextResponse.json(comment);
}
