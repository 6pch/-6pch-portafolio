import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { checkRateLimit, getClientIp } from "@/lib/rateLimit";
import { visitSchema } from "@/lib/validation";

export async function POST(req: NextRequest) {
  const ip = getClientIp(req);

  // Límite generoso: es solo para el contador de analíticas, no un dato crítico.
  if (!checkRateLimit(`visit:${ip}`, 60, 60 * 1000)) {
    return NextResponse.json({ ok: true }); // fallamos en silencio, no es información sensible
  }

  const parsed = visitSchema.safeParse(await req.json().catch(() => ({})));
  const path = parsed.success ? parsed.data.path : "/";

  await prisma.visit.create({ data: { path } });
  return NextResponse.json({ ok: true });
}
