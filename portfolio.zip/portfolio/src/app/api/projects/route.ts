import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { isSameOriginRequest } from "@/lib/verifyOrigin";
import { projectSchema, firstZodError } from "@/lib/validation";

export async function GET() {
  const projects = await prisma.project.findMany({ orderBy: { createdAt: "desc" } });
  return NextResponse.json(projects);
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  if (!isSameOriginRequest(req)) return NextResponse.json({ error: "Origen no válido" }, { status: 403 });

  const parsed = projectSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: firstZodError(parsed.error) }, { status: 400 });
  }
  const data = parsed.data;

  const project = await prisma.project.create({
    data: {
      title: data.title,
      description: data.description,
      content: data.content,
      imageUrl: data.imageUrl || null,
      repoUrl: data.repoUrl || null,
      demoUrl: data.demoUrl || null,
      tags: data.tags,
      featured: data.featured,
    },
  });
  return NextResponse.json(project);
}
