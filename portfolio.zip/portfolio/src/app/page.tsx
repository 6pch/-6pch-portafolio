import { prisma } from "@/lib/prisma";
import { ProjectCard } from "@/components/ProjectCard";
import { ActivityHeatmap } from "@/components/ActivityHeatmap";
import Link from "next/link";

async function getWeeks() {
  const since = new Date();
  since.setDate(since.getDate() - 26 * 7);
  const visits = await prisma.visit.findMany({ where: { createdAt: { gte: since } } });

  const dayCounts = new Map<string, number>();
  for (const v of visits) {
    const key = v.createdAt.toISOString().slice(0, 10);
    dayCounts.set(key, (dayCounts.get(key) ?? 0) + 1);
  }

  const weeks: number[][] = [];
  const today = new Date();
  for (let w = 25; w >= 0; w--) {
    const week: number[] = [];
    for (let d = 0; d < 7; d++) {
      const day = new Date(today);
      day.setDate(today.getDate() - (w * 7 + (6 - d)));
      const key = day.toISOString().slice(0, 10);
      const count = dayCounts.get(key) ?? 0;
      const level = count === 0 ? 0 : count < 2 ? 1 : count < 5 ? 2 : count < 10 ? 3 : 4;
      week.push(level);
    }
    weeks.push(week);
  }
  return weeks;
}

export default async function Home() {
  const [projects, weeks] = await Promise.all([
    prisma.project.findMany({
      orderBy: [{ featured: "desc" }, { order: "asc" }, { createdAt: "desc" }],
      include: { likes: true },
    }),
    getWeeks(),
  ]);

  return (
    <div className="max-w-5xl mx-auto px-5">
      <section className="py-16 md:py-24">
        <p className="font-mono text-xs text-amber mb-3">// hola, soy un desarrollador de 15 años</p>
        <h1 className="font-display text-3xl md:text-5xl font-bold leading-tight max-w-2xl">
          Construyo cosas pequeñas,{" "}
          <span className="text-accent">las subo a producción</span> y aprendo en el camino.
        </h1>
        <p className="text-muted mt-5 max-w-xl leading-relaxed">
          Este sitio es en sí mismo uno de mis proyectos: tiene su propio panel de administración,
          blog y sistema de analíticas hecho a mano. El mapa de abajo son mis visitas reales de las últimas 26 semanas.
        </p>

        <div className="mt-9 overflow-x-auto">
          <ActivityHeatmap weeks={weeks} />
          <p className="font-mono text-[11px] text-muted mt-2">actividad del sitio, en tiempo real</p>
        </div>
      </section>

      <section id="proyectos" className="py-10">
        <h2 className="font-display text-2xl font-semibold mb-6">Proyectos</h2>
        {projects.length === 0 ? (
          <p className="text-muted">Todavía no hay proyectos publicados. Añade el primero desde /admin.</p>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {projects.map((p, i) => (
              <ProjectCard
                key={p.id}
                index={i}
                project={{ ...p, likeCount: p.likes.length }}
              />
            ))}
          </div>
        )}
      </section>

      <section className="py-10">
        <Link href="/blog" className="font-mono text-sm text-accent hover:underline">
          leer el blog →
        </Link>
      </section>
    </div>
  );
}
