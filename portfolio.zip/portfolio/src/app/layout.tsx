import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { Navbar } from "@/components/Navbar";
import { VisitTracker } from "@/components/VisitTracker";
import { SessionProviderClient } from "@/components/SessionProviderClient";

const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display", weight: ["500", "700"] });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono", weight: ["400", "500"] });

export const metadata: Metadata = {
  title: "Mi Portfolio",
  description: "Proyectos, blog y experimentos de un desarrollador que empieza.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={`${display.variable} ${body.variable} ${mono.variable}`} suppressHydrationWarning>
      <body className="font-body min-h-screen flex flex-col">
        <SessionProviderClient>
          <ThemeProvider>
            <VisitTracker />
            <Navbar />
            <main className="flex-1">{children}</main>
            <footer className="border-t border-white/5 py-8 text-center text-muted font-mono text-xs">
              hecho con Next.js · construido paso a paso
            </footer>
          </ThemeProvider>
        </SessionProviderClient>
      </body>
    </html>
  );
}
